package dst1.model.enums;

public enum JobStatus {
SCHEDULED,RUNNING,FAILED,FINISHED
}
